package com.example.DbDemo.Services;

import com.example.DbDemo.Controllers.LoginDto;
import com.example.DbDemo.Controllers.LoginResponse;
import com.example.DbDemo.Dto.EmployeeDto;

public interface EmployeeServices {

    String addEmployee(EmployeeDto employeeDTO);

    LoginResponse loginEmployee(LoginDto loginDto);
}
