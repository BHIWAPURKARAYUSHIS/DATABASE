use dboffice;
create table employee
(
 employee_Id int,
 employee_Name varchar(255),
 email varchar(255),
 password varchar(255)
);