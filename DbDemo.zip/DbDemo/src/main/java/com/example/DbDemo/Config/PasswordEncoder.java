package com.example.DbDemo.Config;

public class PasswordEncoder {
    public String encode(String password) {
        return password;
    }
}
