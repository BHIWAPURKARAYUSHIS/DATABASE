package com.example.DbDemo.Controllers;

public class LoginDto {
}
