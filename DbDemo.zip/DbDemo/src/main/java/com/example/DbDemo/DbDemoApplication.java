package com.example.DbDemo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class DbDemoApplication {
	public static void main(String[] args) {
		SpringApplication.run(DbDemoApplication.class, args);
	}
}
//@GeneratedValue(strategy=GenerationType.AUTO)