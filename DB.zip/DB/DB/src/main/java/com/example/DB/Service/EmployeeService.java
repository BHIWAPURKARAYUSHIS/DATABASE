//package com.example.DB.Service;

//import com.example.DB.Dto.EmployeeDTO;
//import org.springframework.stereotype.Service;
//
//@Service
//public interface EmployeeService {
//String addEmployee(EmployeeDTO employeeDTO);
//}
