package com.example.DbDemo.Entity;

import jakarta.persistence.*;

@Entity
@Table(name= "employee")
public class Employee {
    @Id
    @Column(name= "employee_Id",length=45)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int employee_Id;
    @Column(name= "employee_Name",length=255)
    private String employee_Name;
    @Column(name= "email",length=255)
    private String email;
    @Column(name= "password",length=255)
    private String password;
    public Employee(int employee_Id, String employee_Name, String email, String password) {
        this.employee_Id = employee_Id;
        this.employee_Name = employee_Name;
        this.email = email;
        this.password = password;
    }
    public Employee() {
    }
    public int getEmployee_Id() {
        return employee_Id;
    }
    public void setEmployee_Id(int employee_Id) {
        this.employee_Id = employee_Id;
    }
    public String getEmployee_Name() {
        return employee_Name;
    }
    public void setEmployee_Name(String employee_Name) {
        this.employee_Name = employee_Name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employee_Id=" + employee_Id +
                ", employee_Name='" + employee_Name + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
