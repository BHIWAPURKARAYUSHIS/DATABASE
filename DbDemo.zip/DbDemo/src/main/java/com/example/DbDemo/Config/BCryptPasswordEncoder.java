package com.example.DbDemo.Config;

public class BCryptPasswordEncoder extends PasswordEncoder {
}
