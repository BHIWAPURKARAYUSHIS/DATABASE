package com.example.DbDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
